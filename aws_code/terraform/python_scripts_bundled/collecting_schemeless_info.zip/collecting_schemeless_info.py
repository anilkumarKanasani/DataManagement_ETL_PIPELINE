
import boto3
import json
import time



def trigger_schemeless_info(event , context ):
    pass
    